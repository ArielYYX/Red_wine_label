#include "siftmatch.h"
#include "ui_siftmatch.h"
#include<math.h>
#include<QString>
#include<QFileDialog>
#include <QtCore>
#include <QtGui>
#include<time.h>
#include<cstring>

//加extern "C"，告诉编译器按C语言的方式编译和连接
extern "C"
{
#include "imgfeatures.h"
#include "kdtree.h"
#include "minpq.h"
#include "sift.h"
#include "utils.h"
#include "xform.h"
#include "dir.h"     //创建输出文件夹
}



/* the maximum number of keypoint NN candidates to check during BBF search */
#define KDTREE_BBF_MAX_NN_CHKS 200

/* threshold on squared ratio of distances between NN and 2nd NN */
#define NN_SQ_DIST_RATIO_THR 0.49
//1.0
SiftMatch::SiftMatch(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SiftMatch)
{
    open_image_number = 0;
    m = 0;

    fout.open("../result/out.txt",ios::out);//fout.open("../result/out.txt",ios::out|ios::app);

    CheckDir("../result");   //自动指定输出图片的目录

    ui->setupUi(this);

    ui->textBrowser->setWordWrapMode (QTextOption::NoWrap);
 //   QString matrix= "1\t2\t3\n4\t5\t6\n7\t8\t9\n";
 //   ui->label_77->setText(matrix);
    EnableState(1);                  //开始状态
}
//1.1
SiftMatch::~SiftMatch()
{
    fout.close();
    delete ui;
}
//1.2 打开图片
void SiftMatch::on_action_OpenImage_triggered()
{

    QString img_name = QFileDialog::getOpenFileName(this, tr("Open Image"), "../sift_detect",
                                                    tr("Image Files(*.png *.jpeg *.jpg *.bmp)"));
    //未获取到图片的误操作
    if(img_name.isEmpty())
    {
        return ;
    }
    open_image_number++;
    //打开第1张图片
    if( 1 == open_image_number%2 )
        {
        //刷新页面
        ui->textBrowser->clear();
        src1 = imread( img_name.toLatin1().data() );
        img1 = cvLoadImage( img_name. toLatin1().data() );
        img1_detect = cvLoadImage( img_name. toLatin1().data() );
            //转换成IplImage*类型,但是这样转换过的后面使用起来感觉还是不特别顺利，说明并不是完全100%兼容了。
            imwrite( "../result/src1.jpg", src1 );
            ui->textBrowser->setFixedSize( src1.cols, src1.rows );
            ui->textBrowser->insertHtml( "<img src=../result/src1.jpg>" );
            EnableState(1);  //1.0 初态
         }
    //打开第2张图片
    else if( 0 == open_image_number%2 )
        {

            src2 = imread( img_name. toLatin1().data() );
           img2 = cvLoadImage( img_name.toLatin1().data() );
           img2_detect = cvLoadImage( img_name.toLatin1().data() );
            imwrite( "../result/src2.jpg", src2 );
            ui->textBrowser->setFixedSize( src2.cols+src1.cols, src2.rows+src1.rows  );
            ui->textBrowser->insertHtml( "<img src=../result/src2.jpg>" );

               EnableState (2);  //2.1 状态2的进入

        }
//
    ui->label_11->clear(); ui->label_22->clear();  ui->label_33->clear();
    ui->label_44->clear();    ui->label_55->clear();    ui->label_66->clear();
    ui->label_77->clear();  ui->label_88->clear(); ui->label_99->clear(); ui->label_100->clear();

}

//2.1  特征点检测
void SiftMatch::on_action_SiftDetect_triggered()
{
    //将2幅图片合成1幅图片
    //img1 = cvLoadImage();

    ui->textBrowser->clear();
    //显示第1幅图片上的特征点
    n1 = sift_features( img1_detect, &feat1 );
    draw_features( img1_detect, feat1, n1 );
    src1_detect = Mat(img1_detect);
    imwrite("../result/src1_detect.jpg", src1_detect);
    ui->textBrowser->insertHtml("<img src=../result/src1_detect.jpg>");

    //显示第2幅图片上的特征点
    n2 = sift_features( img2_detect, &feat2 );
    draw_features( img2_detect, feat2, n2 );
    src2_detect = Mat(img2_detect);
    imwrite("../result/src2_detect.jpg", src2_detect);
    ui->textBrowser->insertHtml("<img src=../result/src2_detect.jpg>");

      EnableState(3);//2.2.状态2的递进

    ui->label_11->clear();
    ui->label_22->clear();

    ui->label_33->setText(QString::number(n1+n2,10));

    ui->label_44->clear();
    ui->label_55->clear();
    ui->label_66->clear();
    ui->label_77->clear();

}

//2.2 特征点匹配
void SiftMatch::on_action_SiftMatch_triggered()
{
      //将2幅图片合成1幅图片,img1在左，img2在右
      stacked_sift = stack_imgs_horizontal( img1, img2 );
      //2.2.1 计时开始
      clock_t start,finish;double totaltime;start=clock();
   //根据图1的特征点集feat1建立k-d树，返回k-d树根给kd_root
   kd_root = kdtree_build( feat2, n2 );
   m=0;  //统计匹配点对的个数初始化
   //遍历特征点集feat2，针对feat2中每个特征点feat，选取符合距离比值条件的匹配点，放到feat的fwd_match域中
   for(int i = 0; i < n2; i++ )
       {
           feat = feat1+i;     //第i个特征点的指针
            //在kd_root中搜索目标点feat的2个最近邻点，存放在nbrs中，返回实际找到的近邻点个数
           k = kdtree_bbf_knn( kd_root, feat, 2, &nbrs, KDTREE_BBF_MAX_NN_CHKS );
           if( k == 2 )
               {
                   d0 = descr_dist_sq( feat, nbrs[0] );   //feat与最近邻点的距离的平方
                   d1 = descr_dist_sq( feat, nbrs[1] );   //feat与次近邻点的距离的平方
                   //若d0和d1的比值小于阈值NN_SQ_DIST_RATIO_THR，则接受此匹配，否则剔除
                   if( d0 < d1 * NN_SQ_DIST_RATIO_THR )
                       {
                           pt2 = Point( cvRound( feat->x ), cvRound( feat->y ) );  //将目标点feat和最近邻点作为匹配点对
                           pt1 = Point( cvRound( nbrs[0]->x ), cvRound( nbrs[0]->y ) ); //图1中点的坐标(feat的最近邻点)
                             pt2.x += img1->width;  //左右排列
                           fout<<pt1.x<<" "<<pt1.y<<endl;
                           cvLine( stacked_sift, pt1, pt2, CV_RGB(255,0,255), 1, 8, 0 );    //画出连线
                           m++;                                //统计匹配点对的个数
                           feat1[i].fwd_match = nbrs[0];  //使点feat的fwd_match域指向其对应的匹配点
                       }
               }
            free( nbrs );  //释放近邻数组
        }
     //2.2.1 计时结束
   finish=clock();
   totaltime=(double)(finish-start)/CLOCKS_PER_SEC;
   qDebug()<<"SiftExcudeTime:."<<totaltime<<'s';

   dst_sift = Mat( stacked_sift );
   qDebug()<<"the sum of SIFT feature points:"<<" "<<m;
   fout<<"the sum of SIFT feature points:"<<" "<<m<<endl;                           //保存总匹配对数
   imwrite( "../result/dst_sift.jpg",  dst_sift );
   ui->textBrowser->clear();
   ui->textBrowser->setFixedSize(  dst_sift.cols,  dst_sift.rows );
   ui->textBrowser->insertHtml("<img src=../result/dst_sift.jpg>");
   EnableState(4);//2.2.状态2的递进
   ui->label_11->setText(QString::number(m,10)); ui->label_22->clear();
   ui->label_44->setText(QString::number(totaltime,'g',6));   ui->label_55->clear(); ui->label_66->clear();   ui->label_77->clear();
}





//2.3 ransac 算法

//void SiftMatch::MatrixDecomposition(CvMat * H)
//{
//    // CvMat * H_t=NULL,*H_r=NULL,*H_s=NULL;
//    CvMat* H_t   = cvCreateMat(3,3,CV_32FC1);
//    CvMat* H_r   = cvCreateMat(3,3,CV_32FC1);
//    CvMat* H_s   = cvCreateMat(3,3,CV_32FC1);


////1. *H_t
//    cvmSet(H_t,0,0, 1); cvmSet(H_t,1,0, 0); cvmSet(H_t,2,0, 0);
//    cvmSet(H_t,0,1, 0); cvmSet(H_t,1,1, 1); cvmSet(H_t,2,1, 0);
//    cvmSet(H_t,0,2, cvmGet(H,0,2)); cvmSet(H_t,1,2, cvmGet(H,1,2)); cvmSet(H_t,2,2, 1);
//    //输出H矩阵
//    qDebug()<<"H_t:";
//    for(int i=0;i<3;i++)
//        qDebug()<<cvmGet(H_t,i,0)<<cvmGet(H_t,i,1)<<cvmGet(H_t,i,2);

// //2. *H_s
//    double Sx,Sy;
//    Sx=(double)sqrt( (double)cvmGet(H,0,0)*cvmGet(H,0,0) + (double) cvmGet(H,1,0)*cvmGet(H,1,0) );
//    Sy=(double)sqrt( (double)cvmGet(H,1,0)*cvmGet(H,1,0) + (double)cvmGet(H,1,1)*cvmGet(H,1,1) );
//    cvmSet(H_s,0,0, Sx); cvmSet(H_s,1,0, 0); cvmSet(H_s,2,0, 0);
//    cvmSet(H_s,0,1, 0); cvmSet(H_s,1,1, Sy); cvmSet(H_s,2,1, 0);
//    cvmSet(H_s,0,2, 0); cvmSet(H_s,1,2, 0); cvmSet(H_s,2,2, 1);
//    //输出H矩阵
//    qDebug()<<"H_s:";
//    for(int i=0;i<3;i++)
//        qDebug()<<cvmGet(H_s,i,0)<<cvmGet(H_s,i,1)<<cvmGet(H_s,i,2);

//   //3.*H_r
//    cvmSet(H_r,0,0, cvmGet(H,0,0)/Sx);  cvmSet(H_r,1,0, cvmGet(H,1,0)/Sx); cvmSet(H_r,2,0, 0);
//    cvmSet(H_r,0,1, cvmGet(H,0,1)/Sy);  cvmSet(H_r,1,1, cvmGet(H,1,1)/Sy); cvmSet(H_r,2,1, 0);
//    cvmSet(H_r,0,2, 0);                 cvmSet(H_r,1,2, 0);                cvmSet(H_r,2,2, 1);
//    //输出H矩阵
//    qDebug()<<"H_r:";
//    for(int i=0;i<3;i++)
//        qDebug()<<cvmGet(H_r,i,0)<<cvmGet(H_r,i,1)<<cvmGet(H_r,i,2);

//}

//2.3.1 矩阵分解元素
void SiftMatch::MatrixElement(CvMat * H)
{
    ui->label_88->clear(); ui->label_99->clear(); ui->label_100->clear();
    //平移分量
   double x,y;
   x=cvmGet(H,0,2);y=cvmGet(H,1,2);
   char str[256];
    sprintf(str, "(%.2lf,%.2lf)", x,y);
   ui->label_88->setText( str );
   //缩放的比例
       double Sx,Sy;
       Sx=(double)sqrt( (double)cvmGet(H,0,0)*cvmGet(H,0,0) + (double) cvmGet(H,1,0)*cvmGet(H,1,0) );
       Sy=(double)sqrt( (double)cvmGet(H,1,0)*cvmGet(H,1,0) + (double)cvmGet(H,1,1)*cvmGet(H,1,1) );
   ui->label_99->setText(QString::number(Sx,'g',6));
  //旋转的角度
  double angle= acos(cvmGet(H,0,0)/Sx)/3.14*180;
  ui->label_100->setText(QString::number(angle,'g',6));


}



//2.3.2 RANSAC 精匹配
void SiftMatch::on_action_RansacMatch_triggered()
{
  //如果未提取到匹配对

    //2.3.1 计时开始
    clock_t start,finish;    double totaltime;    start=clock();
        H = ransac_xform(feat1,n1,FEATURE_FWD_MATCH,lsq_homog,4,0.01,homog_xfer_err,3.0,&inliers,&n_inliers);
        //若能成功计算出变换矩阵，即两幅图中有共同区域
          if( H )
          {
             //2.3.2 计时结束
             finish=clock();
             totaltime=(double)(finish-start)/CLOCKS_PER_SEC;
                qDebug()<<"RansacTime:."<<totaltime<<'s'; qDebug()<<"the sum of RANSAC feature points:"<<" "<<n_inliers;
              //将2幅图片合成1幅图片,img1在上，img2在下
              stacked_ransac = stack_imgs_horizontal( img1, img2 );   //合成图像，显示经RANSAC算法筛选后的匹配结果
             //遍历经RANSAC算法筛选后的特征点集合inliers，找到每个特征点的匹配点，画出连线
             for(int i=0; i<n_inliers; i++)
                    {
                        feat = inliers[i];//第i个特征点
                        pt2 = Point(cvRound(feat->x), cvRound(feat->y));//图2中点的坐标
                        pt1 = Point(cvRound(feat->fwd_match->x), cvRound(feat->fwd_match->y));//图1中点的坐标(feat的匹配点)
                        pt2.x += img1->width;//由于两幅图是左右排列的，pt2的横坐标加上图1的宽度，作为连线的终点
                        cvLine(stacked_ransac,pt1,pt2,CV_RGB(255,0,255),1,8,0);//在匹配图上画出连线
                    }
            fout<<"the sum of RANSAC feature points:"<<" "<<n_inliers<<endl;      //输出所有的匹配特征点总数
             dst_ransac = Mat( stacked_ransac );
             imwrite( "../result/dst_ransac.jpg", dst_ransac );
             ui->textBrowser->clear();  ui->textBrowser->setFixedSize( dst_ransac.cols, dst_ransac.rows );  ui->textBrowser->insertHtml("<img src=../result/dst_ransac.jpg>");
            //矩阵转换
//                 CvMat * H_IVT = cvCreateMat(3, 3, CV_64FC1);//变换矩阵的逆矩阵
//                     if( cvInvert(H,H_IVT) )
//                     {
//                         cvReleaseMat(&H);//释放变换矩阵H，因为用不到了
//                         H = cvCloneMat(H_IVT);//将H的逆阵H_IVT中的数据拷贝到H中
//                         cvReleaseMat(&H_IVT);//释放逆阵H_IVT
//                     }


             //输出H矩阵
             QString matrix;
             qDebug()<<"H:";
             for(int i=0;i<3;i++)
             {
             char *str;
             qDebug()<<cvmGet(H,i,0)<<cvmGet(H,i,1)<<cvmGet(H,i,2);
             str=double2str(cvmGet(H,i,0),cvmGet(H,i,1),cvmGet(H,i,2));
             matrix+=str;
             }
             //输出矩阵分量
             MatrixElement(H);

             ui->label_77->setText(matrix);
             //判断角度
             if(cvmGet(H,0,0)<=-0.1)
                 qDebug()<<"angle>90.";
          }//IF H
            EnableState(6);//2.3 状态2的结束+状态3的进入
            //结果显示
             ui->label_22->setText(QString::number(n_inliers,10));ui->label_55->setText(QString::number(totaltime,'g',6));
             double MatchTime=0.0;
              if(0!=m)
              {
                  MatchTime=ui->label_55->text().toDouble()+ ui->label_44->text().toDouble();
                   ui->label_66->setText(QString::number(MatchTime,'g',6));

              }

              else
              {
                  ui->label_22->setText(QString::number(0,10));
                  ui->label_44->setText(QString::number(0,10));
                  ui->label_55->setText(QString::number(0,10));
                  ui->label_66->setText(QString::number(0,10));
              }


}

//___________________________________________________________________________________________________//
//3.1
int SiftMatch::getMatcherFilterType( const string& str )
{
   if( str == "NoneFilter" )
       return NONE_FILTER;
   if( str == "CrossCheckFilter" )
       return CROSS_CHECK_FILTER;
   CV_Error(CV_StsBadArg, "Invalid filter name");
   return -1;
}
//3.2
void SiftMatch::simpleMatching( Ptr<DescriptorMatcher>& descriptorMatcher,
     const Mat& descriptors1, const Mat& descriptors2,
     vector<DMatch>& matches12 )
 {
     vector<DMatch> matches;
     descriptorMatcher->match( descriptors1, descriptors2, matches12 );
 }

//3.3
void SiftMatch::crossCheckMatching( Ptr<DescriptorMatcher>& descriptorMatcher,
    const Mat& descriptors1, const Mat& descriptors2,
    vector<DMatch>& filteredMatches12, int knn=1 )
{
    filteredMatches12.clear();
    vector<vector<DMatch> > matches12, matches21;
    descriptorMatcher->knnMatch( descriptors1, descriptors2, matches12, knn );
    descriptorMatcher->knnMatch( descriptors2, descriptors1, matches21, knn );
    for( size_t m = 0; m < matches12.size(); m++ )
    {
        bool findCrossCheck = false;
        for( size_t fk = 0; fk < matches12[m].size(); fk++ )
        {
            DMatch forward = matches12[m][fk];

            for( size_t bk = 0; bk < matches21[forward.trainIdx].size(); bk++ )
            {
                DMatch backward = matches21[forward.trainIdx][bk];
                if( backward.trainIdx == forward.queryIdx )
                {
                    filteredMatches12.push_back(forward);
                    findCrossCheck = true;
                    break;
                }
            }
            if( findCrossCheck ) break;
        }
    }
}
//3.4
void SiftMatch::warpPerspectiveRand( const Mat& src, Mat& dst, Mat& H, RNG& rng )
{
    H.create(3, 3, CV_32FC1);
    H.at<float>(0,0) = rng.uniform( 0.8f, 1.2f);
    H.at<float>(0,1) = rng.uniform(-0.1f, 0.1f);
    H.at<float>(0,2) = rng.uniform(-0.1f, 0.1f)*src.cols;
    H.at<float>(1,0) = rng.uniform(-0.1f, 0.1f);
    H.at<float>(1,1) = rng.uniform( 0.8f, 1.2f);
    H.at<float>(1,2) = rng.uniform(-0.1f, 0.1f)*src.rows;
    H.at<float>(2,0) = rng.uniform( -1e-4f, 1e-4f);
    H.at<float>(2,1) = rng.uniform( -1e-4f, 1e-4f);
    H.at<float>(2,2) = rng.uniform( 0.8f, 1.2f);

    warpPerspective( src, dst, H, src.size() );
}

//3.5 OpenCV 特征点匹配的函数
void SiftMatch::doIteration( const Mat& img1, Mat& img2, bool isWarpPerspective,
    vector<KeyPoint>& keypoints1, const Mat& descriptors1,
    Ptr<FeatureDetector>& detector, Ptr<DescriptorExtractor>& descriptorExtractor,
    Ptr<DescriptorMatcher>& descriptorMatcher, int matcherFilter, bool eval,
    double ransacReprojThreshold, RNG& rng ,Mat& drawImg ,int flag)
{
  assert( !img1.empty() );
  Mat H12;
      if( isWarpPerspective )
          warpPerspectiveRand(img1, img2, H12, rng );
      else
          assert( !img2.empty() );
      vector<KeyPoint> keypoints2;
      detector->detect( img2, keypoints2 );
      cout <<"second image:"<< keypoints2.size() << " points" << endl ;
      //两图特征点的总数：
     ui->label_33->setText(QString::number(keypoints1.size()+keypoints2.size(),10));

      if( !H12.empty() && eval )
          {
              cout << "< Evaluate feature detector..." << endl;
              float repeatability;
              int correspCount;
              evaluateFeatureDetector( img1, img2, H12, &keypoints1, &keypoints2, repeatability, correspCount );
              cout << "repeatability = " << repeatability << endl;
              cout << "correspCount = " << correspCount << endl;
              cout << ">" << endl;
          }
      Mat descriptors2;
          descriptorExtractor->compute( img2, keypoints2, descriptors2 );
          vector<DMatch> filteredMatches;
              switch( matcherFilter )
              {
              case CROSS_CHECK_FILTER :
                  crossCheckMatching( descriptorMatcher, descriptors1, descriptors2, filteredMatches, 1 );
                  break;
              default :
                  simpleMatching( descriptorMatcher, descriptors1, descriptors2, filteredMatches );
              }

      if( !H12.empty() && eval )
          {
              cout << "< Evaluate descriptor matcher..." << endl;
              vector<Point2f> curve;
              Ptr<GenericDescriptorMatcher> gdm = new VectorDescriptorMatcher( descriptorExtractor, descriptorMatcher );
              evaluateGenericDescriptorMatcher( img1, img2, H12, keypoints1, keypoints2, 0, 0, curve, gdm );

              Point2f firstPoint = *curve.begin();
              Point2f lastPoint = *curve.rbegin();
              int prevPointIndex = -1;
              cout << "1-precision = " << firstPoint.x << "; recall = " << firstPoint.y << endl;
              for( float l_p = 0; l_p <= 1 + FLT_EPSILON; l_p+=0.05f )
              {
                  int nearest = getNearestPoint( curve, l_p );
                  if( nearest >= 0 )
                  {
                      Point2f curPoint = curve[nearest];
                      if( curPoint.x > firstPoint.x && curPoint.x < lastPoint.x && nearest != prevPointIndex )
                      {
                          cout << "1-precision = " << curPoint.x << "; recall = " << curPoint.y << endl;
                          prevPointIndex = nearest;
                      }
                  }
              }
              cout << "1-precision = " << lastPoint.x << "; recall = " << lastPoint.y << endl;
              cout << ">" << endl;
          }//if

      vector<int> queryIdxs( filteredMatches.size() ), trainIdxs( filteredMatches.size() );
          for( size_t i = 0; i < filteredMatches.size(); i++ )
          {
              queryIdxs[i] = filteredMatches[i].queryIdx;
              trainIdxs[i] = filteredMatches[i].trainIdx;
          }

          if( !isWarpPerspective && ransacReprojThreshold >= 0&& flag )
          {
              vector<Point2f> points1; KeyPoint::convert(keypoints1, points1, queryIdxs);
              vector<Point2f> points2; KeyPoint::convert(keypoints2, points2, trainIdxs);
              H12 = findHomography( Mat(points1), Mat(points2), CV_RANSAC, ransacReprojThreshold );

          }

        //  Mat drawImg;
          if( !H12.empty() ) // filter outliers
          {
              vector<char> matchesMask( filteredMatches.size(), 0 );
              vector<Point2f> points1; KeyPoint::convert(keypoints1, points1, queryIdxs);
              vector<Point2f> points2; KeyPoint::convert(keypoints2, points2, trainIdxs);
              Mat points1t; perspectiveTransform(Mat(points1), points1t, H12);

              double maxInlierDist = ransacReprojThreshold < 0 ? 3 : ransacReprojThreshold;
              for( size_t i1 = 0; i1 < points1.size(); i1++ )
              {
                  if( norm(points2[i1] - points1t.at<Point2f>((int)i1,0)) <= maxInlierDist ) // inlier
                      matchesMask[i1] = 1;
              }
              // draw inliers
              drawMatches( img1, keypoints1, img2, keypoints2, filteredMatches, drawImg, CV_RGB(0, 255, 0), CV_RGB(0, 0, 255), matchesMask
      #if DRAW_RICH_KEYPOINTS_MODE
                  , DrawMatchesFlags::DRAW_RICH_KEYPOINTS
      #endif
                  );

      #if DRAW_OUTLIERS_MODE
              // draw outliers
              for( size_t i1 = 0; i1 < matchesMask.size(); i1++ )
                  matchesMask[i1] = !matchesMask[i1];
              drawMatches( img1, keypoints1, img2, keypoints2, filteredMatches, drawImg, CV_RGB(0, 0, 255), CV_RGB(255, 0, 0), matchesMask,
                  DrawMatchesFlags::DRAW_OVER_OUTIMG | DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS );
      #endif

              cout << "Number of RANSAC inliers: " << countNonZero(matchesMask) << endl;
              //结果显示
              ui->label_22->setText(QString::number(countNonZero(matchesMask),10));
              //输出H矩阵
              QString matrix;
              qDebug()<<"H:";
              for(int i=0;i<3;i++)
              {
              char *str;
              qDebug()<<H12.at<double>(i,0)<<H12.at<double>(i,1)<<H12.at<double>(i,2);
              str=double2str(H12.at<double>(i,0),H12.at<double>(i,1),H12.at<double>(i,2));
              matrix+=str;
              }
              ui->label_77->setText(matrix);
              //输出矩阵分量
              CvMat H_ransac=H12;
              MatrixElement(&H_ransac);

          }
          else
              drawMatches( img1, keypoints1, img2, keypoints2, filteredMatches, drawImg );

}

//3.6  sift 特征点提取
void SiftMatch::on_action_OpencvSIFT_triggered()
{
    int SiftFlag=0;
    bool isWarpPerspective = 0;
    double ransacReprojThreshold = 3;
    cv::initModule_nonfree();
    Ptr<FeatureDetector> detector = FeatureDetector::create( "SIFT");
    Ptr<DescriptorExtractor> descriptorExtractor = DescriptorExtractor::create( "SIFT");
    Ptr<DescriptorMatcher> descriptorMatcher = DescriptorMatcher::create( "FlannBased");//("BruteForce");
    int mactherFilterType = getMatcherFilterType( "CrossCheckFilter");
    bool eval = false;
    if( detector.empty() || descriptorExtractor.empty() || descriptorMatcher.empty()  )
    {
        cout << "Can not create detector or descriptor exstractor or descriptor matcher of given types" << endl;
        return ;
    }
  //  Mat img1 = imread( "../result/3.jpg" );
  //  Mat img2 = imread( "../result/4.jpg");
    Mat src1_opencv=src1.clone();
    Mat src2_opencv=src2.clone();


    if( src1_opencv.empty() || (!isWarpPerspective && src2_opencv.empty()) )
        {
            cout << "Can not read images" << endl;
            return ;
        }

        //cout << endl << "< Extracting keypoints from first image..." << endl;
        vector<KeyPoint> keypoints1;
        detector->detect( src1_opencv, keypoints1 );
        cout << "first image:"<<keypoints1.size() << " points" << endl ; //<< ">" << endl;

        //cout << "< Computing descriptors for keypoints from first image..." << endl;


        Mat descriptors1;
        descriptorExtractor->compute( src1_opencv, keypoints1, descriptors1 );
        //cout << ">" << endl;
        RNG rng = theRNG();
        //
        doIteration( src1_opencv, src2_opencv, isWarpPerspective, keypoints1, descriptors1,
            detector, descriptorExtractor, descriptorMatcher, mactherFilterType, eval,
            ransacReprojThreshold, rng,opencv_sift,SiftFlag );


        imwrite( "../result/opencv_sift.jpg", opencv_sift );
        ui->textBrowser->clear();
        ui->textBrowser->setFixedSize(  opencv_sift.cols,  opencv_sift.rows );
        ui->textBrowser->insertHtml("<img src=../result/opencv_sift.jpg>");


        EnableState(5); //2.2 状态2的递进
        return ;

}

//3.7  RANSAC 提纯算法
void SiftMatch::on_action_OpencvRANSAC_triggered()
{
    int RansacFlag=1;
    bool isWarpPerspective = 0;
    double ransacReprojThreshold = 3;
    cv::initModule_nonfree();
    Ptr<FeatureDetector> detector = FeatureDetector::create( "SIFT");
    Ptr<DescriptorExtractor> descriptorExtractor = DescriptorExtractor::create( "SIFT");
    Ptr<DescriptorMatcher> descriptorMatcher = DescriptorMatcher::create( "FlannBased");//("BruteForce");
    int mactherFilterType = getMatcherFilterType( "CrossCheckFilter");
    bool eval = false;
    if( detector.empty() || descriptorExtractor.empty() || descriptorMatcher.empty()  )
    {
        cout << "Can not create detector or descriptor exstractor or descriptor matcher of given types" << endl;
        return ;
    }
    //  Mat img1 = imread( "../result/3.jpg" );
    //  Mat img2 = imread( "../result/4.jpg");
    Mat src1_opencv=src1.clone();
    Mat src2_opencv=src2.clone();

    if( src1_opencv.empty() || (!isWarpPerspective && src2_opencv.empty()) )
        {
            cout << "Can not read images" << endl;
            return ;
        }

        //cout << endl << "< Extracting keypoints from first image..." << endl;
        vector<KeyPoint> keypoints1;
        detector->detect( src1_opencv, keypoints1 );
        cout << "first image:"<<keypoints1.size() << " points" << endl ; //<< ">" << endl;
        //cout << "< Computing descriptors for keypoints from first image..." << endl;
        Mat descriptors1;
        descriptorExtractor->compute( src1_opencv, keypoints1, descriptors1 );
        //cout << ">" << endl;
//3.7.1 计时开始
        clock_t start,finish;
        double totaltime;
         start=clock();

        RNG rng = theRNG();
        doIteration( src1_opencv, src2_opencv, isWarpPerspective, keypoints1, descriptors1,
            detector, descriptorExtractor, descriptorMatcher, mactherFilterType, eval,
            ransacReprojThreshold, rng,opencv_ransac,RansacFlag );
//3.7.2 计时结束
        finish=clock();
        totaltime=(double)(finish-start)/CLOCKS_PER_SEC;
        qDebug()<<"RansacTime:."<<totaltime<<'s';

        imwrite( "../result/opencv_ransac.jpg",opencv_ransac );
    {
        ui->textBrowser->clear();
        ui->textBrowser->setFixedSize(  opencv_ransac.cols,  opencv_ransac.rows );
        ui->textBrowser->insertHtml("<img src=../result/opencv_ransac.jpg>");


        EnableState(6);  //2.3 状态2的结束+状态3的进入

        //结果显示
       ui->label_55->setText(QString::number(totaltime,'g',6));
       ui->label_66->setText(QString::number(totaltime,'g',6));

        return ;
   }
}

//4.1 状态栏的释放状态
/*order:
1. 开始  (1)
2.1 状态2的进入(2);  2.2.状态2的递进(3 4 5);   2.3 状态2的结束+状态3的进入(6)；
3. 终态(1)
*/
void SiftMatch::EnableState(int order)
{
    if(1==order)
    {
        ui->action_OpenImage->setEnabled(true);   //启用下列按钮.
        ui->action_SiftDetect->setEnabled(false);
        ui->action_SiftMatch->setEnabled(false);
        ui->action_RansacMatch->setEnabled(false);
        ui->action_OpencvSIFT->setEnabled(false);
        ui->action_OpencvRANSAC->setEnabled(false);

    }
    else if(2==order)//2.0
    {
        ui->action_OpenImage->setEnabled(false);   //启用下列按钮
        ui->action_SiftDetect->setEnabled(true);
        ui->action_SiftMatch->setEnabled(false);
        ui->action_RansacMatch->setEnabled(false);
        ui->action_OpencvSIFT->setEnabled(true);
        ui->action_OpencvRANSAC->setEnabled(false);

    }
    else  if(3==order)   //2.1
    {
        ui->action_OpenImage->setEnabled(false);   //启用下列按钮
        ui->action_SiftDetect->setEnabled(false);
        ui->action_SiftMatch->setEnabled(true);
        ui->action_RansacMatch->setEnabled(false);
        ui->action_OpencvSIFT->setEnabled(false);
        ui->action_OpencvRANSAC->setEnabled(false);

    }
    else  if(4==order)
    {
        ui->action_OpenImage->setEnabled(false);   //启用下列按钮
        ui->action_SiftDetect->setEnabled(false);
        ui->action_SiftMatch->setEnabled(false);
        ui->action_RansacMatch->setEnabled(true);
        ui->action_OpencvSIFT->setEnabled(false);
        ui->action_OpencvRANSAC->setEnabled(false);

    }
    else  if(5==order)//2.2
    {
        ui->action_OpenImage->setEnabled(false);   //启用下列按钮
        ui->action_SiftDetect->setEnabled(false);
        ui->action_SiftMatch->setEnabled(false);
        ui->action_RansacMatch->setEnabled(false);
        ui->action_OpencvSIFT->setEnabled(false);
        ui->action_OpencvRANSAC->setEnabled(true);

    }
    else  if(6==order)  //3
    {
        ui->action_OpenImage->setEnabled(true);   //启用下列按钮
        ui->action_SiftDetect->setEnabled(false);
        ui->action_SiftMatch->setEnabled(false);
        ui->action_RansacMatch->setEnabled(false);
        ui->action_OpencvSIFT->setEnabled(false);
        ui->action_OpencvRANSAC->setEnabled(false);

    }


}
//4.2  double convert to char*
char* SiftMatch::double2str(double data1,double data2,double data3)
{
    char str[256];

    sprintf(str, "%.6lf\t%.6lf\t%.6lf\n", data1,data2,data3); //%.6lf\n  d=lf
    return str;
}
