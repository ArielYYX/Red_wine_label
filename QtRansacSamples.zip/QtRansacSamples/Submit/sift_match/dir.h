#ifndef DIR_H
#define DIR_H


#include <stdio.h>
#include <direct.h>
#include <stdlib.h>
#include <memory>

//检查文件夹是否存在，不存在则创建之
//文件夹存在返回 0
//文件夹创建失败返回-1
//文件夹创建失败返回1
int CheckDir(char* Dir)
{
    FILE *fp = NULL;
    char TempDir[200];
    memset(TempDir,'\0',sizeof(TempDir));
    sprintf(TempDir,Dir);
    strcat(TempDir,"\\");
    strcat(TempDir,".temp.fortest");
    fp = fopen(TempDir,"w");
    if (!fp)
    {
        if(_mkdir(Dir)==0)
        {
            return 1;//文件夹创建成功
        }
        else
        {
            return -1;//can not make a dir;
        }
    }
    else
    {
        fclose(fp);
    }
    return 0;
}



#endif // DIR_H
