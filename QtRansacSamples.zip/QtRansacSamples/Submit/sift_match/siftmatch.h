#ifndef SIFTMATCH_H
#define SIFTMATCH_H
#include<iostream>

#include<fstream>
#include <QMainWindow>
#include<opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/nonfree.hpp>

using namespace cv;
using namespace std;
namespace Ui {
class SiftMatch;
}
//_______________global variable__________________________//
#define DRAW_RICH_KEYPOINTS_MODE     0
#define DRAW_OUTLIERS_MODE           0

enum { NONE_FILTER = 0, CROSS_CHECK_FILTER = 1 };


//________________________________________________________//

class SiftMatch : public QMainWindow
{
    Q_OBJECT

public:
    explicit SiftMatch(QWidget *parent = 0);
    ~SiftMatch();

private slots:

//    void MatrixDecomposition(CvMat * H);
//1.1
    void on_action_OpenImage_triggered();
//2.1
    void on_action_SiftDetect_triggered();

    void on_action_SiftMatch_triggered();

    void on_action_RansacMatch_triggered();


    void MatrixElement(CvMat * H);
//3.6
    void on_action_OpencvSIFT_triggered();

    void on_action_OpencvRANSAC_triggered();


private:
    Ui::SiftMatch *ui;
    Mat src1, src2, src1_detect, src2_detect,  dst_sift, dst_ransac;
    Mat opencv_sift,opencv_ransac;
    IplImage *img1, *img2;      //IplImage格式的原图
    IplImage *img1_detect, *img2_detect;  //画上特征点之后的图
    IplImage *stacked_sift; //显示匹配结果的合成图像，显示经距离比值法筛选后的匹配结果
    IplImage *stacked_ransac;//显示匹配结果的合成图像，显示经RANSAC算法筛选后的匹配结果

    Point pt1, pt2;
    double d0, d1;
    struct feature *feat1, *feat2, *feat; //feat1：图1的特征点数组，feat2：图2的特征点数组  feat: 每个特征点
    struct feature **nbrs;     //当前特征点的最近邻点数组
    struct kd_node *kd_root;  //k-d树的树根
    int open_image_number;    //打开图片个数
    int n1, n2, k, i, m;     //n1:图1中的特征点个数，n2：图2中的特征点个数
    fstream fout;

    CvMat * H;//RANSAC算法求出的变换矩阵
    struct feature **inliers;//精RANSAC筛选后的内点数组
    int n_inliers;//经RANSAC算法筛选后的内点个数,即feat2中具有符合要求的特征点的个数

// 3.0
    int getMatcherFilterType( const string& str );  //3.1
    void simpleMatching( Ptr<DescriptorMatcher>& descriptorMatcher,const Mat& descriptors1,
                         const Mat& descriptors2,vector<DMatch>& matches12 ); //3.2
    void crossCheckMatching( Ptr<DescriptorMatcher>& descriptorMatcher,
        const Mat& descriptors1, const Mat& descriptors2,
        vector<DMatch>& filteredMatches12, int knn );//3.3
    void warpPerspectiveRand( const Mat& src, Mat& dst, Mat& H, RNG& rng );//3.4

    void doIteration( const Mat& img1, Mat& img2, bool isWarpPerspective,
        vector<KeyPoint>& keypoints1, const Mat& descriptors1,
        Ptr<FeatureDetector>& detector, Ptr<DescriptorExtractor>& descriptorExtractor,
        Ptr<DescriptorMatcher>& descriptorMatcher, int matcherFilter, bool eval,
        double ransacReprojThreshold, RNG& rng, Mat& drawImg ,int flag ); //3.5
// 4.1
    /*order:
    1. 开始  (1)
    2.1 状态2的进入(2);  2.2.状态2的递进(3);   2.3 状态2的结束+状态3的进入(4)；
    3. 终态(5)
    */
    void EnableState(int order);
//  4.2
    char* double2str(double data1,double data2,double data3);

};


#endif // SIFTMATCH_H
