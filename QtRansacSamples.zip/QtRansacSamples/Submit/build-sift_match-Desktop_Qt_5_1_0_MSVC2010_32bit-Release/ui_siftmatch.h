/********************************************************************************
** Form generated from reading UI file 'siftmatch.ui'
**
** Created by: Qt User Interface Compiler version 5.1.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIFTMATCH_H
#define UI_SIFTMATCH_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SiftMatch
{
public:
    QAction *action_SiftMatch;
    QAction *action_RansacMatch;
    QAction *action_OpencvSIFT;
    QAction *action_OpencvRANSAC;
    QAction *action_SiftDetect;
    QAction *action_OpenImage;
    QWidget *centralWidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_1;
    QLabel *label_2;
    QLabel *label_3;
    QWidget *verticalLayoutWidget_4;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_11;
    QLabel *label_22;
    QLabel *label_33;
    QWidget *verticalLayoutWidget_7;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_77;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QTextBrowser *textBrowser;
    QLabel *label_7;
    QWidget *verticalLayoutWidget_5;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QWidget *verticalLayoutWidget_6;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_44;
    QLabel *label_55;
    QLabel *label_66;
    QWidget *verticalLayoutWidget_8;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_8;
    QLabel *label_88;
    QLabel *label_9;
    QLabel *label_99;
    QLabel *label_10;
    QLabel *label_100;
    QMenuBar *menuBar;
    QMenu *menuOpenImage_O;
    QMenu *menu2_SiftDetect;
    QMenu *menu3_Opencv;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *SiftMatch)
    {
        if (SiftMatch->objectName().isEmpty())
            SiftMatch->setObjectName(QStringLiteral("SiftMatch"));
        SiftMatch->setEnabled(true);
        SiftMatch->resize(821, 583);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(SiftMatch->sizePolicy().hasHeightForWidth());
        SiftMatch->setSizePolicy(sizePolicy);
        SiftMatch->setAcceptDrops(true);
        action_SiftMatch = new QAction(SiftMatch);
        action_SiftMatch->setObjectName(QStringLiteral("action_SiftMatch"));
        action_RansacMatch = new QAction(SiftMatch);
        action_RansacMatch->setObjectName(QStringLiteral("action_RansacMatch"));
        action_OpencvSIFT = new QAction(SiftMatch);
        action_OpencvSIFT->setObjectName(QStringLiteral("action_OpencvSIFT"));
        action_OpencvRANSAC = new QAction(SiftMatch);
        action_OpencvRANSAC->setObjectName(QStringLiteral("action_OpencvRANSAC"));
        action_SiftDetect = new QAction(SiftMatch);
        action_SiftDetect->setObjectName(QStringLiteral("action_SiftDetect"));
        action_OpenImage = new QAction(SiftMatch);
        action_OpenImage->setObjectName(QStringLiteral("action_OpenImage"));
        centralWidget = new QWidget(SiftMatch);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayoutWidget = new QWidget(centralWidget);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(0, 500, 691, 21));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(verticalLayoutWidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        verticalLayoutWidget_3 = new QWidget(centralWidget);
        verticalLayoutWidget_3->setObjectName(QStringLiteral("verticalLayoutWidget_3"));
        verticalLayoutWidget_3->setGeometry(QRect(0, 330, 110, 171));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_3);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_1 = new QLabel(verticalLayoutWidget_3);
        label_1->setObjectName(QStringLiteral("label_1"));

        verticalLayout_3->addWidget(label_1);

        label_2 = new QLabel(verticalLayoutWidget_3);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout_3->addWidget(label_2);

        label_3 = new QLabel(verticalLayoutWidget_3);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout_3->addWidget(label_3);

        verticalLayoutWidget_4 = new QWidget(centralWidget);
        verticalLayoutWidget_4->setObjectName(QStringLiteral("verticalLayoutWidget_4"));
        verticalLayoutWidget_4->setGeometry(QRect(110, 330, 101, 171));
        verticalLayout_4 = new QVBoxLayout(verticalLayoutWidget_4);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_11 = new QLabel(verticalLayoutWidget_4);
        label_11->setObjectName(QStringLiteral("label_11"));

        verticalLayout_4->addWidget(label_11);

        label_22 = new QLabel(verticalLayoutWidget_4);
        label_22->setObjectName(QStringLiteral("label_22"));

        verticalLayout_4->addWidget(label_22);

        label_33 = new QLabel(verticalLayoutWidget_4);
        label_33->setObjectName(QStringLiteral("label_33"));

        verticalLayout_4->addWidget(label_33);

        verticalLayoutWidget_7 = new QWidget(centralWidget);
        verticalLayoutWidget_7->setObjectName(QStringLiteral("verticalLayoutWidget_7"));
        verticalLayoutWidget_7->setGeometry(QRect(430, 360, 261, 141));
        verticalLayout_7 = new QVBoxLayout(verticalLayoutWidget_7);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        label_77 = new QLabel(verticalLayoutWidget_7);
        label_77->setObjectName(QStringLiteral("label_77"));

        verticalLayout_7->addWidget(label_77);

        verticalLayoutWidget_2 = new QWidget(centralWidget);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(0, 0, 691, 331));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        textBrowser = new QTextBrowser(verticalLayoutWidget_2);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textBrowser->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_2->addWidget(textBrowser);

        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(520, 340, 71, 16));
        verticalLayoutWidget_5 = new QWidget(centralWidget);
        verticalLayoutWidget_5->setObjectName(QStringLiteral("verticalLayoutWidget_5"));
        verticalLayoutWidget_5->setGeometry(QRect(220, 330, 110, 171));
        verticalLayout_5 = new QVBoxLayout(verticalLayoutWidget_5);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(verticalLayoutWidget_5);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout_5->addWidget(label_4);

        label_5 = new QLabel(verticalLayoutWidget_5);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout_5->addWidget(label_5);

        label_6 = new QLabel(verticalLayoutWidget_5);
        label_6->setObjectName(QStringLiteral("label_6"));

        verticalLayout_5->addWidget(label_6);

        verticalLayoutWidget_6 = new QWidget(centralWidget);
        verticalLayoutWidget_6->setObjectName(QStringLiteral("verticalLayoutWidget_6"));
        verticalLayoutWidget_6->setGeometry(QRect(330, 330, 101, 171));
        verticalLayout_6 = new QVBoxLayout(verticalLayoutWidget_6);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        label_44 = new QLabel(verticalLayoutWidget_6);
        label_44->setObjectName(QStringLiteral("label_44"));

        verticalLayout_6->addWidget(label_44);

        label_55 = new QLabel(verticalLayoutWidget_6);
        label_55->setObjectName(QStringLiteral("label_55"));

        verticalLayout_6->addWidget(label_55);

        label_66 = new QLabel(verticalLayoutWidget_6);
        label_66->setObjectName(QStringLiteral("label_66"));

        verticalLayout_6->addWidget(label_66);

        verticalLayoutWidget_8 = new QWidget(centralWidget);
        verticalLayoutWidget_8->setObjectName(QStringLiteral("verticalLayoutWidget_8"));
        verticalLayoutWidget_8->setGeometry(QRect(690, 330, 131, 191));
        verticalLayout_8 = new QVBoxLayout(verticalLayoutWidget_8);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(verticalLayoutWidget_8);
        label_8->setObjectName(QStringLiteral("label_8"));

        verticalLayout_8->addWidget(label_8);

        label_88 = new QLabel(verticalLayoutWidget_8);
        label_88->setObjectName(QStringLiteral("label_88"));

        verticalLayout_8->addWidget(label_88);

        label_9 = new QLabel(verticalLayoutWidget_8);
        label_9->setObjectName(QStringLiteral("label_9"));

        verticalLayout_8->addWidget(label_9);

        label_99 = new QLabel(verticalLayoutWidget_8);
        label_99->setObjectName(QStringLiteral("label_99"));

        verticalLayout_8->addWidget(label_99);

        label_10 = new QLabel(verticalLayoutWidget_8);
        label_10->setObjectName(QStringLiteral("label_10"));

        verticalLayout_8->addWidget(label_10);

        label_100 = new QLabel(verticalLayoutWidget_8);
        label_100->setObjectName(QStringLiteral("label_100"));

        verticalLayout_8->addWidget(label_100);

        SiftMatch->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(SiftMatch);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 821, 23));
        menuOpenImage_O = new QMenu(menuBar);
        menuOpenImage_O->setObjectName(QStringLiteral("menuOpenImage_O"));
        menu2_SiftDetect = new QMenu(menuBar);
        menu2_SiftDetect->setObjectName(QStringLiteral("menu2_SiftDetect"));
        menu3_Opencv = new QMenu(menuBar);
        menu3_Opencv->setObjectName(QStringLiteral("menu3_Opencv"));
        SiftMatch->setMenuBar(menuBar);
        mainToolBar = new QToolBar(SiftMatch);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        SiftMatch->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(SiftMatch);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        SiftMatch->setStatusBar(statusBar);

        menuBar->addAction(menuOpenImage_O->menuAction());
        menuBar->addAction(menu2_SiftDetect->menuAction());
        menuBar->addAction(menu3_Opencv->menuAction());
        menuOpenImage_O->addAction(action_OpenImage);
        menu2_SiftDetect->addAction(action_SiftDetect);
        menu2_SiftDetect->addAction(action_SiftMatch);
        menu2_SiftDetect->addAction(action_RansacMatch);
        menu3_Opencv->addAction(action_OpencvSIFT);
        menu3_Opencv->addAction(action_OpencvRANSAC);

        retranslateUi(SiftMatch);

        QMetaObject::connectSlotsByName(SiftMatch);
    } // setupUi

    void retranslateUi(QMainWindow *SiftMatch)
    {
        SiftMatch->setWindowTitle(QApplication::translate("SiftMatch", "SiftMatch", 0));
        action_SiftMatch->setText(QApplication::translate("SiftMatch", "2.2 SiftMatch", 0));
        action_RansacMatch->setText(QApplication::translate("SiftMatch", "2.3 RansacMatch", 0));
        action_OpencvSIFT->setText(QApplication::translate("SiftMatch", "3.1 OpencvSIFT", 0));
        action_OpencvRANSAC->setText(QApplication::translate("SiftMatch", "3.2 OpencvRANSAC", 0));
        action_SiftDetect->setText(QApplication::translate("SiftMatch", "2.1 SiftDetect", 0));
        action_OpenImage->setText(QApplication::translate("SiftMatch", "1.1 OpenImage", 0));
        label->setText(QApplication::translate("SiftMatch", "                  CopyRight @ BUCT-\350\256\241\347\247\2211104\347\217\255-2011014283-\344\273\243 \351\224\213-\346\257\225\344\270\232\350\256\276\350\256\241\346\274\224\347\244\272\347\250\213\345\272\217", 0));
        label_1->setText(QApplication::translate("SiftMatch", "\347\262\227\345\214\271\351\205\215\347\211\271\345\276\201\347\202\271\346\225\260\357\274\232", 0));
        label_2->setText(QApplication::translate("SiftMatch", "\347\262\276\345\214\271\351\205\215\347\211\271\345\276\201\347\202\271\346\225\260\357\274\232", 0));
        label_3->setText(QApplication::translate("SiftMatch", "\344\270\244\345\233\276SIFT\347\211\271\345\276\201\347\202\271\346\225\260\357\274\232", 0));
        label_11->setText(QApplication::translate("SiftMatch", "<html><head/><body><p>TextLable</p></body></html>", 0));
        label_22->setText(QApplication::translate("SiftMatch", "TextLabel", 0));
        label_33->setText(QApplication::translate("SiftMatch", "TextLabel", 0));
        label_77->setText(QApplication::translate("SiftMatch", "TextLabel", 0));
        label_7->setText(QApplication::translate("SiftMatch", "\345\217\230\346\215\242\347\237\251\351\230\265H\357\274\232", 0));
        label_4->setText(QApplication::translate("SiftMatch", "\347\262\227\345\214\271\351\205\215\347\232\204\346\227\266\351\227\264\357\274\232", 0));
        label_5->setText(QApplication::translate("SiftMatch", "Ransac\345\214\271\351\205\215\347\232\204\346\227\266\351\227\264\357\274\232", 0));
        label_6->setText(QApplication::translate("SiftMatch", "\345\233\276\345\203\217\345\214\271\351\205\215\347\232\204\346\200\273\346\227\266\351\227\264\357\274\232", 0));
        label_44->setText(QApplication::translate("SiftMatch", "TextLabel", 0));
        label_55->setText(QApplication::translate("SiftMatch", "TextLabel", 0));
        label_66->setText(QApplication::translate("SiftMatch", "TextLabel", 0));
        label_8->setText(QApplication::translate("SiftMatch", "\345\271\263\347\247\273\345\210\206\351\207\217\357\274\232", 0));
        label_88->setText(QApplication::translate("SiftMatch", "TextLabel", 0));
        label_9->setText(QApplication::translate("SiftMatch", "\347\274\251\346\224\276\346\257\224\344\276\213\357\274\232", 0));
        label_99->setText(QApplication::translate("SiftMatch", "TextLabel", 0));
        label_10->setText(QApplication::translate("SiftMatch", "\346\227\213\350\275\254\350\247\222\345\272\246\357\274\232", 0));
        label_100->setText(QApplication::translate("SiftMatch", "TextLabel", 0));
        menuOpenImage_O->setTitle(QApplication::translate("SiftMatch", "1. Open", 0));
        menu2_SiftDetect->setTitle(QApplication::translate("SiftMatch", "2.notOpencv", 0));
        menu3_Opencv->setTitle(QApplication::translate("SiftMatch", "3.Opencv", 0));
    } // retranslateUi

};

namespace Ui {
    class SiftMatch: public Ui_SiftMatch {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIFTMATCH_H
